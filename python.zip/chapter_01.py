
# Load required packages

import matplotlib.pyplot as plt
